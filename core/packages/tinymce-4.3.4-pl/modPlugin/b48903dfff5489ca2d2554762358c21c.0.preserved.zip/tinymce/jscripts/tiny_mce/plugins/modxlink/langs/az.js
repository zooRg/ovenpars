tinyMCE.addI18n('az.modxlink',{
    link_desc:"Insert/edit link"
});