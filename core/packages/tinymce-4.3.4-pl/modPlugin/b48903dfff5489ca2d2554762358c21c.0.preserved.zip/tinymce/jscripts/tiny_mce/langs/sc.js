tinyMCE.addI18n({sc:{
common:{
edit_confirm:"\u662F\u5426\u5728\u6B64textarea\u6807\u7B7E\u5185\u4F7F\u7528\u300C\u6240\u89C1\u5373\u6240\u5F97\u300D\u6A21\u5F0F\uFF1F ",
apply:"\u5E94\u7528",
insert:"\u63D2\u5165",
update:"\u66F4\u65B0",
cancel:"\u53D6\u6D88",
close:"\u5173\u95ED",
browse:"\u6D41\u89C8",
class_name:"\u6837\u5F0F",
not_set:"--\u672A\u8BBE\u7F6E--",
clipboard_msg:"\u590D\u5236\u3001\u526A\u4E0B\u3001\u8D34\u4E0A\u529F\u80FD\u5728Mozilla\u548CFirefox\u4E2D\u4E0D\u80FD\u4F7F\u7528\u3002 \n\u662F\u5426\u9700\u8981\u4E86\u89E3\u66F4\u591A\u6709\u5173\u6B64\u95EE\u9898\u7684\u8D44\u8BAF\uFF1F ",
clipboard_no_support:"\u8FD8\u4E0D\u652F\u63F4\u60A8\u7684\u6D41\u89C8\u5668\uFF0C\u8BF7\u4F7F\u7528\u952E\u76D8\u5FEB\u6377\u65B9\u5F0F",
popup_blocked:"\u62B1\u6B49\uFF01\u5F39\u51FA\u89C6\u7A97\u5DF2\u88AB\u963B\u6B62\uFF0C\u8BF7\u8C03\u6574\u6D41\u89C8\u5668\u8BBE\u7F6E\uFF0C\u5141\u8BB8\u6B64\u7F51\u7AD9\u53EF\u5F39\u51FA\u65B0\u89C6\u7A97\uFF0C\u4EE5\u4FBF\u4F7F\u7528\u6B64\u5DE5\u5177",
invalid_data:"\u9519\u8BEF:\u65E0\u6548\u8F93\u5165\u503C\uFF0C\u5DF2\u6807\u8BB0\u4E3A\u7EA2\u8272\u3002 ",
more_colors:"\u66F4\u591A\u989C\u8272"
},
contextmenu:{
align:"\u5BF9\u9F50\u65B9\u5F0F",
left:"\u9760\u5DE6\u5BF9\u9F50",
center:"\u5C45\u4E2D\u5BF9\u9F50",
right:"\u9760\u53F3\u5BF9\u9F50",
full:"\u4E24\u7AEF\u5BF9\u9F50"
},
insertdatetime:{
date_fmt:"%Y-%m-%d",
time_fmt:"%H:%M:%S",
insertdate_desc:"\u63D2\u5165\u4ECA\u5929\u65E5\u671F",
inserttime_desc:"\u63D2\u5165\u73B0\u5728\u65F6\u95F4",
months_long:"\u4E00\u6708,\u4E8C\u6708,\u4E09\u6708,\u56DB\u6708,\u4E94\u6708,\u516D\u6708,\u4E03\u6708,\u516B\u6708,\u4E5D\u6708,\u5341\u6708,\u5341\u4E00\u6708,\u5341\u4E8C\u6708",
months_short:"1\u6708,2\u6708,3\u6708,4\u6708,5\u6708,6\u6708,7\u6708,8\u6708,9\u6708,10\u6708,11\u6708,12\u6708",
day_long:"\u661F\u671F\u65E5,\u661F\u671F\u4E00,\u661F\u671F\u4E8C,\u661F\u671F\u4E09,\u661F\u671F\u56DB,\u661F\u671F\u4E94,\u661F\u671F\u516D,\u661F\u671F\u65E5",
day_short:"\u5468\u65E5,\u5468\u4E00,\u5468\u4E8C,\u5468\u4E09,\u5468\u56DB,\u5468\u4E94,\u5468\u516D,\u5468\u65E5"
},
print:{
print_desc:"\u5217\u5370"
},
preview:{
preview_desc:"\u9884\u89C8"
},
directionality:{
ltr_desc:"\u6587\u5B57\u4ECE\u5DE6\u5230\u53F3",
rtl_desc:"\u6587\u5B57\u4ECE\u53F3\u5230\u5DE6"
},
layer:{
insertlayer_desc:"\u63D2\u5165\u5C42",
forward_desc:"\u7F6E\u524D",
backward_desc:"\u7F6E\u540E",
absolute_desc:"\u5F00\u5173\u7EDD\u5BF9\u4F4D\u7F6E",
content:"\u65B0\u589E\u5C42..."
},
save:{
save_desc:"\u4FDD\u5B58",
cancel_desc:"\u53D6\u6D88\u6240\u6709\u66F4\u6539"
},
nonbreaking:{
nonbreaking_desc:"\u63D2\u5165\u7A7A\u767D\u683C"
},
iespell:{
iespell_desc:"\u62FC\u5199\u68C0\u67E5",
download:"\u672A\u68C0\u6D4B\u5230ieSpell\u7684\u5B58\u5728\u3002\u662F\u5426\u73B0\u5728\u7ACB\u5373\u5B89\u88C5\uFF1F "
},
advhr:{
advhr_desc:"\u6C34\u5E73\u7EBF"
},
emotions:{
emotions_desc:"\u56FE\u91CA"
},
searchreplace:{
search_desc:"\u67E5\u627E",
replace_desc:"\u67E5\u627E/\u66FF\u6362"
},
advimage:{
image_desc:"\u63D2\u5165/\u7F16\u8F91\u56FE\u7247"
},
advlink:{
link_desc:"\u63D2\u5165/\u7F16\u8F91\u8FDE\u7ED3"
},
xhtmlxtras:{
cite_desc:"\u5F15\u6587",
abbr_desc:"\u7F29\u5199",
acronym_desc:"\u9996\u5B57\u7F29\u5199",
del_desc:"\u5220\u9664",
ins_desc:"\u63D2\u5165",
attribs_desc:"\u63D2\u5165/\u7F16\u8F91\u5C5E\u6027",
attribs_delta_width:"40",
attribs_delta_height:"60"
},
style:{
desc:"\u7F16\u8F91CSS\u6837\u5F0F\u8868\u5355"
},
paste:{
paste_text_desc:"\u4EE5\u7EAF\u6587\u672C\u8D34\u4E0A",
paste_word_desc:"\u4ECEWord\u8D34\u4E0A",
selectall_desc:"\u5168\u9009",
plaintext_mode_sticky:"Paste is now in plain text mode. Click again to toggle back to regular paste mode. After you paste something you will be returned to regular paste mode.",
plaintext_mode:"Paste is now in plain text mode. Click again to toggle back to regular paste mode."
},
paste_dlg:{
text_title:"\u5728\u952E\u76D8\u4E0A\u540C\u65F6\u6309\u4E0BCTRL\u548CV\u952E\uFF0C\u4EE5\u8D34\u4E0A\u6587\u5B57\u5230\u6B64\u89C6\u7A97\u3002 ",
text_linebreaks:"\u4FDD\u7559\u6362\u884C\u7B26\u53F7",
word_title:"\u5728\u952E\u76D8\u4E0A\u540C\u65F6\u6309\u4E0BCTRL\u548CV\u952E\uFF0C\u4EE5\u8D34\u4E0A\u6587\u5B57\u5230\u6B64\u89C6\u7A97\u3002 "
},
table:{
desc:"\u63D2\u5165\u65B0\u8868\u683C",
row_before_desc:"\u63D2\u5165\u4E0A\u65B9\u884C",
row_after_desc:"\u63D2\u5165\u4E0B\u65B9\u884C",
delete_row_desc:"\u5220\u9664\u6240\u5728\u884C",
col_before_desc:"\u63D2\u5165\u5DE6\u65B9\u5217",
col_after_desc:"\u63D2\u5165\u53F3\u65B9\u5217",
delete_col_desc:"\u5220\u9664\u6240\u5728\u5217",
split_cells_desc:"\u5206\u5272\u5355\u683C",
merge_cells_desc:"\u5408\u5E76\u5355\u683C",
row_desc:"\u884C\u5C5E\u6027",
cell_desc:"\u5355\u683C\u5C5E\u6027",
props_desc:"\u8868\u683C\u5C5E\u6027",
paste_row_before_desc:"\u8D34\u5728\u4E0A\u884C",
paste_row_after_desc:"\u8D34\u5728\u4E0B\u884C",
cut_row_desc:"\u526A\u4E0B\u9009\u62E9\u884C",
copy_row_desc:"\u590D\u5236\u9009\u62E9\u884C",
del:"\u5220\u9664\u8868\u683C",
row:"\u884C",
col:"\u5217",
cell:"\u5355\u683C",
cellprops_delta_width:"10",
cellprops_delta_height:"10",
table_delta_width:"40",
table_delta_height:"60",
merge_cells_delta_width:"40",
merge_cells_delta_height:"40"
},
autosave:{
unload_msg:"\u5982\u679C\u79BB\u5F00\u6B64\u9875\u9762\u5C06\u5BFC\u81F4\u6240\u505A\u7684\u66F4\u6539\u5168\u90E8\u4E22\u5931\u3002 ",
restore_content:"Restore auto-saved content.",
warning_message:"If you restore the saved content, you will lose all the content that is currently in the editor.\n\nAre you sure you want to restore the saved content?."
},
fullscreen:{
desc:"\u5F00\u5173\u5168\u5C4F\u6A21\u5F0F"
},
media:{
desc:"\u63D2\u5165/\u7F16\u8F91\u5D4C\u5165\u5A92\u4F53",
edit:"\u7F16\u8F91\u5D4C\u5165\u5A92\u4F53"
},
fullpage:{
desc:"\u6863\u5C5E\u6027"
},
template:{
desc:"\u63D2\u5165\u9884\u5B9A\u7684\u8303\u672C\u5185\u5BB9"
},
visualchars:{
desc:"\u663E\u793A\u63A7\u5236\u7B26\u53F7\u5F00/\u5173\u3002 "
},
spellchecker:{
desc:"\u5F00\u5173\u62FC\u5199\u68C0\u67E5",
menu:"\u62FC\u5199\u68C0\u67E5\u8BBE\u7F6E",
ignore_word:"\u7565\u8FC7",
ignore_words:"\u5168\u90E8\u7565\u8FC7",
langs:"\u8BED\u8A00",
wait:"\u8BF7\u7A0D\u5019...",
sug:"\u63A8\u8350\u5B57\u8BCD",
no_sug:"\u65E0\u62FC\u5199\u63A8\u8350",
no_mpell:"\u672A\u53D1\u73B0\u62FC\u5199\u9519\u8BEF"
},
pagebreak:{
desc:"\u63D2\u5165\u5206\u9875\u7B26\u53F7"
},
advlist:{
types:"Types",
def:"Default",
lower_alpha:"Lower alpha",
lower_greek:"Lower greek",
lower_roman:"Lower roman",
upper_alpha:"Upper alpha",
upper_roman:"Upper roman",
circle:"Circle",
disc:"Disc",
square:"Square"
}}});