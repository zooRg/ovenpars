<?php
/**
 * Russian permissions Lexicon Entries for ovenpars
 *
 * @package ovenpars
 * @subpackage lexicon
 */
$_lang['ovenpars_save'] = 'Permission for save/update data.';