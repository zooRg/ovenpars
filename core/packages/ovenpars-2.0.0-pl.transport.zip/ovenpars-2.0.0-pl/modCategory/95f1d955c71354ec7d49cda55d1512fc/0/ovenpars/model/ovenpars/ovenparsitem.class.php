<?php

/**
 * @package ovenpars
 */
class ovenparsItem extends xPDOSimpleObject
{
}