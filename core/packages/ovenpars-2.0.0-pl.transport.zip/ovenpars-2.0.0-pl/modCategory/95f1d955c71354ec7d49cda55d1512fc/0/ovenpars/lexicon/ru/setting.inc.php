<?php

$_lang['area_ovenpars_main'] = 'Основные';

$_lang['setting_ovenpars_some_setting'] = 'Какая-то настройка';
$_lang['setting_ovenpars_some_setting_desc'] = 'Это описание для какой-то настройки';