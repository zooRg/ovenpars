<?php
require_once (dirname(__DIR__) . '/ovenparsitem.class.php');
class ovenparsItem_mysql extends ovenparsItem {}