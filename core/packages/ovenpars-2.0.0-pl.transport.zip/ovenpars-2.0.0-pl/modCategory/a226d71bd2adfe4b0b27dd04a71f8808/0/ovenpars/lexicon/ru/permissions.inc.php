<?php
/**
 * English permissions Lexicon Entries for ovenpars
 *
 * @package ovenpars
 * @subpackage lexicon
 */
$_lang['ovenpars_save'] = 'Разрешает создание/изменение данных.';