<?php

$_lang['area_ovenpars_main'] = 'Настройки парсинга';
$_lang['area_ovenpars_import'] = 'Настройки Импорта в каталог';

$_lang['setting_url'] = 'URL';
$_lang['setting_url_desc'] = 'УРЛ сайта откуда парсим товары';
$_lang['setting_container'] = 'Контейнер';
$_lang['setting_container_desc'] = 'Клас контейнер товаров';
$_lang['setting_item'] = 'Товары';
$_lang['setting_item_desc'] = 'Клас товара на сайте парсинга';

$_lang['setting_section_id'] = 'ID раздела';
$_lang['setting_template_id'] = 'ID шаблона';
$_lang['setting_price_tv'] = 'Поле с ценой';
$_lang['setting_desc_tv'] = 'Поле с описанием';
$_lang['setting_image_tv'] = 'Поле с картинками';